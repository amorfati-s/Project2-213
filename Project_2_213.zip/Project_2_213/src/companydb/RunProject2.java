package companydb;

/**
 * This is the driver class with the main method that calls the run method in
 * PayrollProcessing.java
 *
 * @author Siddhi Kasera, Sonal Madhok
 */
public class RunProject2 {
    public static void main(String[] args) {
        new PayrollProcessing().run();
    }
}