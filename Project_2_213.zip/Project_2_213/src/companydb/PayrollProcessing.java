package companydb;

import java.util.Scanner;

/**
 * This class processes the commands entered in the command line.
 *
 * @author Siddhi Kasera, Sonal Madhok
 **/
public class PayrollProcessing {
    Scanner in = new Scanner(System.in);
    Company companyDB = new Company();
    public static String name;
    public static String deptName;
    public static String dateHiredStr;
    public static double annualSalary;
    private final String CS_DEPT = "CS";
    private final String ECE_DEPT = "ECE";
    private final String IT_DEPT = "IT";
    private final int MAX_PT_HOURS = 100;
    private int numEmployee;
    private String[] arrOfStr;

    /**
     * This method reads from the command line, parses the input and calls the
     * respective functions.
     */
    public void run() {
        System.out.println("Payroll Processing starts.");
        //Declare/Initialize variables
        String command;
        String line;
        boolean hasNextLine = in.hasNext();

        //Using Scanner for Getting input from user
        while (hasNextLine) {
            line = in.nextLine(); //nextLine reads
            arrOfStr = line.split(" "); //Tokenizing the array from the Scanner
            command = arrOfStr[0];

            switch (command) {
                case "AF":  //handling command add
                    name = arrOfStr[1];
                    deptName = arrOfStr[2];
                    dateHiredStr = arrOfStr[3];
                    annualSalary = Double.parseDouble(arrOfStr[4]);
                    Profile AFProfile = new Profile(name, deptName, dateHiredStr);
                    Fulltime fulltimeEmp = new Fulltime(AFProfile, annualSalary);

                    if (annualSalary < 0) {
                        System.out.println("Salary cannot be negative.");
                    } else if (!(deptName.equals(CS_DEPT) || deptName.equals(IT_DEPT) || deptName.equals(ECE_DEPT))) {
                        System.out.println("'" + deptName + "' is not a valid department code.");
                    } else if (AFProfile.getDateHired().isValid()) {
                        if (companyDB.add(fulltimeEmp)) {
                            System.out.println("Employee added.");
                        } else {
                            System.out.println("Employee is already in the list.");
                        }
                    } else {
                        System.out.println(fulltimeEmp.getProfile().getDateHired().getMonth() + "/" + fulltimeEmp.getProfile().getDateHired().getDay() + "/" +
                                fulltimeEmp.getProfile().getDateHired().getYear() + " is not a valid date!");
                    }
                    break;
                case "AP":  //handling command add
                    name = arrOfStr[1];
                    deptName = arrOfStr[2];
                    dateHiredStr = arrOfStr[3];
                    double hourlyPay = Double.parseDouble(arrOfStr[4]);
                    Profile APProfile = new Profile(name, deptName, dateHiredStr);
                    Parttime parttimeEmp = new Parttime(APProfile, hourlyPay);

                    if (hourlyPay < 0) {
                        System.out.println("Salary cannot be negative.");
                    } else if (!(deptName.equals(CS_DEPT) || deptName.equals(IT_DEPT) || deptName.equals(ECE_DEPT))) {
                        System.out.println("'" + deptName + "' is not a valid department code.");
                    } else if (APProfile.getDateHired().isValid()) {
                        if (companyDB.add(parttimeEmp)) {
                            System.out.println("Employee added.");
                        } else {
                            System.out.println("Employee is already in the list.");
                        }
                    } else {
                        System.out.println(parttimeEmp.getProfile().getDateHired().getMonth() + "/" + parttimeEmp.getProfile().getDateHired().getDay() + "/" +
                                parttimeEmp.getProfile().getDateHired().getYear() + " is not a valid date!");
                    }
                    break;

                case "AM":  //handling command add
                    name = arrOfStr[1];
                    deptName = arrOfStr[2];
                    dateHiredStr = arrOfStr[3];
                    annualSalary = Double.parseDouble(arrOfStr[4]);
                    int role = Integer.parseInt(arrOfStr[5]);
                    Profile AMProfile = new Profile(name, deptName, dateHiredStr);
                    Management mngmntEmp = new Management(AMProfile, annualSalary, role);

                    if (role > 3) {
                        System.out.println("Invalid management code.");
                    } else if (annualSalary < 0) {
                        System.out.println("Salary cannot be negative.");
                    } else if (!(deptName.equals(CS_DEPT) || deptName.equals(IT_DEPT) || deptName.equals(ECE_DEPT))) {
                        System.out.println("'" + deptName + "' is not a valid department code.");
                    } else if (AMProfile.getDateHired().isValid()) {
                        if (companyDB.add(mngmntEmp)) {
                            System.out.println("Employee added.");
                        } else {
                            System.out.println("Employee is already in the list.");
                        }
                    } else {
                        System.out.println(mngmntEmp.getProfile().getDateHired().getMonth() + "/" + mngmntEmp.getProfile().getDateHired().getDay() + "/" +
                                mngmntEmp.getProfile().getDateHired().getYear() + " is not a valid date!");
                    }
                    break;

                case "R":  //handling command remove employee
                    name = arrOfStr[1];
                    deptName = arrOfStr[2];
                    dateHiredStr = arrOfStr[3];
                    Profile RProfile = new Profile(name, deptName, dateHiredStr);
                    Employee removeEmp = new Employee(RProfile);

                    if (!(deptName.equals(CS_DEPT) || deptName.equals(IT_DEPT) || deptName.equals(ECE_DEPT))) {
                        System.out.println("'" + deptName + "' is not a valid department code.");
                    } else if (numEmployee == 0) {
                        System.out.println("Employee database is empty.");
                    } else if (RProfile.getDateHired().isValid()) {
                        if (companyDB.remove(removeEmp)) {
                            System.out.println("Employee removed.");
                        } else {
                            System.out.println("Employee does not exist.");
                        }
                    } else {
                        System.out.println(removeEmp.getProfile().getDateHired().getMonth() + "/" + removeEmp.getProfile().getDateHired().getDay() + "/" +
                                removeEmp.getProfile().getDateHired().getYear() + " is not a valid date!");
                    }
                    break;

                case "C": //handling command calculate
                    numEmployee = companyDB.getNumEmployee();
                    if (numEmployee == 0) {
                        System.out.println("Employee database is empty.");
                    } else {
                        companyDB.processPayments();
                        System.out.println("Calculation of employees is done.");
                    }
                    break;

                case "S": //handling setHours command for part time employee
                    name = arrOfStr[1];
                    deptName = arrOfStr[2];
                    dateHiredStr = arrOfStr[3];
                    double hours = Double.parseDouble(arrOfStr[4]);
                    Profile setHrsProfile = new Profile(name, deptName, dateHiredStr);
                    Parttime setHrsEmp = new Parttime(setHrsProfile);
                    numEmployee = companyDB.getNumEmployee();
                    setHrsEmp.setHours(hours); //temporarily setting the hours to this profile in order to see if it exists in our database

                    if (numEmployee == 0) {
                        System.out.println("Employee database is empty.");
                    } else if (!(deptName.equals(CS_DEPT) || deptName.equals(IT_DEPT) || deptName.equals(ECE_DEPT))) {
                        System.out.println("'" + deptName + "' is not a valid department code.");
                    } else if (hours < 0) {
                        System.out.println("Working hours cannot be negative.");
                    } else if (hours > MAX_PT_HOURS) {
                        System.out.println("Invalid hours: over 100.");
                    } else if (setHrsProfile.getDateHired().isValid()) {
                        if (companyDB.setHours(setHrsEmp)) {
                            System.out.println("Working hours set.");
                        } else {
                            System.out.println("Employee does not exist");
                        }
                    } else {
                        System.out.println(setHrsEmp.getProfile().getDateHired().getMonth() + "/" + setHrsEmp.getProfile().getDateHired().getDay() + "/" +
                                setHrsEmp.getProfile().getDateHired().getYear() + " is not a valid date!");
                    }
                    break;

                case "PA":  //printing the list of books
                    companyDB.print();
                    break;

                case "PH": //printing the list of books by date
                    companyDB.printByDate();
                    break;

                case "PD": //printing the list of books by serial number
                    companyDB.printByDepartment();
                    break;

                case "Q": //exiting a kiosk session
                    System.out.println("Payroll Processing completed.");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Command " + "'" + arrOfStr[0] + "'" + " is not supported!");
                    break;
            }
        }

    }
}